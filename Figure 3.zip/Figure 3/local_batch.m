function [ ] = local_batch( )

% Run all the simulations (saves both single- and repeat-release info)
% for i = 1:(3*4*50)
%     gen_data_single_sim(i);
%     disp(num2str(i))
% end

for i = 1:(3*4)
    gen_data_single_sim_keep_traces(i);
    disp(num2str(i))
end

end