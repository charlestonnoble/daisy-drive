function [ ] = gather_data_repeatrelease( )

%#ok<*LAXES>
addpath('../../Plotting Functions/')

close all

elements = 2:5;

clrs = plot_colors(length(elements));
hdl = figure('position',[671   157   473   529]);
ha = tight_subplot(3,2,[0.06,0.1],[0.08,0.04],[0.1,0.05]);
plot_opts = {'TickDir','Out','TickLength',[0.0200 0.0250]};
leg_opts = {'FontSize',8,'Box','Off'};

hdl = plot_single_sims('Data_single_sims/', hdl, ha, clrs, plot_opts, ...
    leg_opts);
plot_arr = zeros(length(elements),1);
for i = 1:length(elements)
    n = elements(i);
    clr = clrs(i,:);
    [hdl, pl] = plot_t99(['./Data_' num2str(n) '_elements/'], hdl, ha, clr, ...
        plot_opts, leg_opts);
    plot_arr(i) = pl;
end

axes(ha(2))
leg_cell = cell(length(elements),1);
for j = 1:length(elements)
    leg_cell{j} = [num2str(elements(j)) ' elements'];
end
leg = legend(plot_arr, leg_cell);
set(leg,'Location','Southwest')
set(leg,leg_opts{:})

set(gcf,'Units','Inches');
pos = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits','Inches',...
    'PaperSize',[pos(3), pos(4)])

end

% ======================================================================= %
function arr = plot_colors(curve_count)

arr = brewermap(2*curve_count,'*BrBG'); 
arr = arr([curve_count:-1:1, end:-1:curve_count+1],:);

end

% ======================================================================= %
function [hdl_out] = plot_single_sims(fpath, hdl_in, ha, clrs, ...
    plot_opts, leg_opts)

lw = 1;

f_arr = dir(fpath);
f_arr = f_arr(4:end);
N = length(f_arr);

param_arr = zeros(N, 3);
time_cell = cell(N,1);
freq_cell = cell(N,1);

set(0,'CurrentFigure',hdl_in)

for i = 1:N
    f = f_arr(i);
    d = load([fpath '/' f.name]);
    param_arr(i,:) = [d.n, d.P, d.d0];
    T = d.T_repeat;
    Y = d.Y_repeat;
    payload_freq = Y(:,end);
    time_cell{i} = T;
    freq_cell{i} = payload_freq;
end

n_arr = unique(param_arr(:,1));
P_arr = unique(param_arr(:,2));

for i = 1:length(P_arr)
    axes(ha(2*(i-1)+1)); hold on;
    for j = 1:length(n_arr)
        idx = find(param_arr(:,2) == P_arr(i) & param_arr(:,1) == n_arr(j)); 
        plot(time_cell{idx},freq_cell{idx},'Color',clrs(j,:),'linewidth',lw);
    end
    xlim([0,100])
    ylim([0,1])
%     set(gca,'yscale','log'); set(gca,'ylim',[10^-4,1])
    ylabel('Payload frequency')
    if i == 1
        leg_cell = cell(length(n_arr),1);
        for j = 1:length(n_arr)
            leg_cell{j} = [num2str(n_arr(j)) ' elements'];
        end
        leg = legend(leg_cell);
        set(leg,'Location','Southeast')
        set(leg,leg_opts{:})
    end
    if i == length(P_arr)
        xlabel('Time (generations)')
    end
    set(gca,plot_opts{:})
end

hdl_out = gcf;

end

% ======================================================================= %
function [hdl_out, pl] = plot_t99(fpath, hdl_in, ha, clr, plot_opts, leg_opts)

mkr_siz = 9;

f_arr = dir(fpath);
f_arr = f_arr(3:end);
N = length(f_arr);

param_arr = zeros(N, 3);

max_freqs = zeros(N, 1);
t99_times = zeros(N, 1);

for i = 1:N
    f = f_arr(i);
    d = load([fpath '/' f.name]);
    param_arr(i,:) = [d.n, d.P, d.d0];
    T = d.T_repeat;
    Y = d.Y_repeat;
    [max_freq, t99] = analyze(T,Y);
    max_freqs(i) = max_freq;
    t99_times(i) = t99;
end

n_arr = unique(param_arr(:,1));
P_arr = unique(param_arr(:,2));

set(0,'CurrentFigure',hdl_in)

for i = 1:length(P_arr)
    axes(ha(2*(i-1)+2)); hold on;
    pl_bck = plot([10^-3,1],[20,20],'Color',0.8*ones(1,3),'linewidth',2);
    for j = 1:length(n_arr)
        t99_idxs = ...
            param_arr(:,1) == n_arr(j) & ...
            param_arr(:,2) == P_arr(i);
        t99_vals = t99_times(t99_idxs);
        d0_vals = param_arr(t99_idxs,3);
        [~,I] = sort(d0_vals);
        t99_vals = t99_vals(I);
        d0_vals = d0_vals(I);
        pl_temp = plot(d0_vals(1:2:end), t99_vals(1:2:end), '.-', 'markersize', mkr_siz, 'color', clr(j,:));
        if i == 1
            pl = pl_temp; 
        end
    end
    uistack(pl_bck,'bottom')
    set(gca,'yscale','log')
    set(gca,'xscale','log')
    ylim([5,100])
    xlim([10^-3,1])
    set(gca,plot_opts{:})
    if i == length(P_arr)
        xlabel('Release frequency');
    end
    ylabel('Generations to 0.99')
end

hdl_out = gcf;

end

% ======================================================================= %
function [max_freq, t99] = analyze(T,Y)

Y = Y(:,end);
max_freq = max(Y);
t99_idx = find(Y>0.99,1,'first');

if ~isempty(t99_idx)
    t99 = T(t99_idx);
else
    t99 = NaN;
end

end